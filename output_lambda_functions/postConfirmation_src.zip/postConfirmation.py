import boto3 # type: ignore
import os

# Inicializa el cliente de SNS
sns = boto3.client('sns')
topic_arn = os.environ['SNS_TOPIC_ARN']

def lambda_handler(event, context):
    # Obtener el correo del usuario desde el evento de Cognito
    email = event['request']['userAttributes']['email']
    
    try:
        # Suscribir el correo al tema de SNS
        response = sns.subscribe(
            TopicArn=topic_arn,
            Protocol='email',
            Endpoint=email
        )
        return {
            'statusCode': 200,
            'body': f"Usuario suscrito al tema SNS: {email}"
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': f"Error al suscribir el usuario: {str(e)}"
        }
